package com.example.robotpohybrotat;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import lejos.remote.ev3.RemoteRequestEV3;
import lejos.remote.ev3.RemoteRequestPilot;
import lejos.remote.ev3.RemoteRequestSampleProvider;
import lejos.robotics.Color;
import lejos.utility.Delay;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.example.robotpohybrotat.RotationControl.RotationListener;
 
public class MainActivity extends Activity implements OnTouchListener,
        RotationListener, OnSeekBarChangeListener,OnCheckedChangeListener,SensorEventListener {
  
	private String HOST = "", Diam = "", WheelDiam = "", selection , colorName , slot1="." , slot2="." ,slot3="." ,slot4="."  ;
    private RemoteRequestEV3 ev3;
    private RemoteRequestPilot pilot;
    private int angle;
    private ImageButton forward, backward , connect , switch_obr;
    private Button buttonA, buttonB , buttonC ,buttonD , Commands ,buttonLeft , buttonRight , buttonForward , buttonBackward;
    private ImageView shake;
    private SeekBar speed, rotationSpeed , left , right, forw , back;
    private TextView speedValue, rotationSpeedValue , leftValue , rightValue, backwardValue, forwardValue;
    private EditText sensorA,sensorB,sensorC,sensorD;
    private AlertDialog.Builder dialogBuilder;
    private lejos.hardware.Audio audio;
    private EditText wifi,wheel,diameter;
    private RadioGroup radgrp;
    private boolean switch_bool=false;
    RotationControl rotateView;
    private SensorManager Manager;
    private float x = 0, z = 0;
    Sensor Accelerom;
    LayoutInflater factory;
    private String [] sensors = {"Ultrasonic sensor", "Color sensor" , "Gyro sensor", "None"};
    private String [] connected = {"None", "None" , "None", "None"};
    private List<String> commands;
    private int SPEED_FACTOR = 2, TURN_FACTOR = 10;
    private float [] ultraSample, colorSample, gyroSample;
    private RemoteRequestSampleProvider ultraSP,colorSP,gyroSP;
    private ExecutorService threads = Executors.newCachedThreadPool();

   
    
    
 
    @SuppressLint("InflateParams")
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        factory = LayoutInflater.from(this);
          
        Manager = (SensorManager) getSystemService(SENSOR_SERVICE);
                
        connect = (ImageButton) findViewById(R.id.connect);
        connect.setOnTouchListener(this);
        
        buttonA = (Button) findViewById(R.id.buttonA);
        buttonA.setOnTouchListener(this);
        
        buttonB = (Button) findViewById(R.id.buttonB);
        buttonB.setOnTouchListener(this);
        
        buttonC = (Button) findViewById(R.id.buttonC);
        buttonC.setOnTouchListener(this);
        
        buttonD = (Button) findViewById(R.id.buttonD);
        buttonD.setOnTouchListener(this);
        
        Commands = (Button) findViewById(R.id.Commands);
        Commands.setOnTouchListener(this);
        
        switch_obr = (ImageButton) findViewById(R.id.switch_off);
        switch_obr.setOnTouchListener(this);
           
        forward = (ImageButton) findViewById(R.id.forward);
        forward.setOnTouchListener(this);
 
        backward = (ImageButton) findViewById(R.id.backward);
        backward.setOnTouchListener(this);
        
        shake = (ImageView) findViewById(R.id.shake);
        shake.setVisibility(View.INVISIBLE);
        
         
        speed = (SeekBar) findViewById(R.id.speed);
        speed.setOnSeekBarChangeListener(this); 
        speedValue = (TextView) findViewById(R.id.speedValue);
        speed.setProgress(50);
         
        rotationSpeed = (SeekBar) findViewById(R.id.rotateSpeed);
        rotationSpeed.setOnSeekBarChangeListener(this); 
        rotationSpeedValue = (TextView) findViewById(R.id.rotateSpeedValue);
        rotationSpeed.setProgress(50);
 
        rotateView = (RotationControl) findViewById(R.id.rotate);
        rotateView.setRotationListener(this);
        
        radgrp = (RadioGroup) findViewById(R.id.radioGroup1);
        radgrp.setOnCheckedChangeListener((OnCheckedChangeListener) this);
        
        sensorA = (EditText) findViewById(R.id.sensorA);
        sensorB = (EditText) findViewById(R.id.sensorB);
        sensorC = (EditText) findViewById(R.id.sensorC);
        sensorD = (EditText) findViewById(R.id.sensorD);
        
        sensorA.setText(slot1);
        sensorB.setText(slot2);
        sensorC.setText(slot3);
        sensorD.setText(slot4);
        
 
        
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        
    }
    
    @SuppressLint("ClickableViewAccessibility")
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
    	getMenuInflater().inflate(R.menu.main, menu);
		return false;
		
    }
    
     
    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        // TODO Auto-generated method stub
    	
 
    	int cid = radgrp.getCheckedRadioButtonId();
    	
    	switch(cid){
        case R.id.radio0:
        	if(ev3!=null){
            	try{
            		pilot = (RemoteRequestPilot) ev3.createPilot(Float.parseFloat(WheelDiam), Float.parseFloat(Diam),"B", "C");
            	}
            	catch(Exception e){ }
        	}
            break;
        
        case R.id.radio1:
        	if(ev3!=null){
        		try{
            		pilot = (RemoteRequestPilot) ev3.createPilot(Float.parseFloat(WheelDiam), Float.parseFloat(Diam),"A", "B");
                	}
                	catch(Exception e){ }
            	}
            break;
        
        case R.id.radio2:
            if(ev3!=null){
            	try{
            		pilot = (RemoteRequestPilot) ev3.createPilot(Float.parseFloat(WheelDiam), Float.parseFloat(Diam),"C", "D");
                	}
                	catch(Exception e){ }
            	}       	
            break;    
        }
    
    }
    
    
    @SuppressLint({ "NewApi", "InflateParams" })
	private void connectDialog(){
    	
    	dialogBuilder = new AlertDialog.Builder(this);
    	
    	View dialogView = factory.inflate(R.layout.alert_dialog, null);
    	dialogBuilder.setView(dialogView);
          	
    	wifi = (EditText) dialogView.findViewById(R.id.Wifi_id);
        wheel = (EditText) dialogView.findViewById(R.id.Wheel);
        diameter = (EditText) dialogView.findViewById(R.id.Distance);
    	   	
        dialogBuilder.setMessage("Robot parameters");
        dialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				HOST = wifi.getText().toString();
				Diam = diameter.getText().toString();
				WheelDiam = wheel.getText().toString();
				if(Diam.length() == 0 || WheelDiam.length() == 0){
					Toast.makeText(MainActivity.this, "Some Diameter missing",Toast.LENGTH_LONG).show();
				}
				else{
				new Control().execute("connect", HOST);
				}
			}
        }); 
        
        AlertDialog connectip = dialogBuilder.create();
        connectip.show();
    }
    
   
    
    
    @SuppressLint({ "NewApi", "InflateParams" })
	private void commandsDialog(){
    	
    	commands = new ArrayList<String>();;
    	dialogBuilder = new AlertDialog.Builder(this);
    	
    	View dialogView = factory.inflate(R.layout.commands_dialog, null);
    	dialogBuilder.setView(dialogView);
          	
    	left = (SeekBar) dialogView.findViewById(R.id.left);
    	left.setOnSeekBarChangeListener(this); 
    	leftValue = (TextView) dialogView.findViewById(R.id.leftValue);
    	left.setMax(180);
         
        right = (SeekBar) dialogView.findViewById(R.id.right);
        right.setOnSeekBarChangeListener(this); 
        rightValue = (TextView) dialogView.findViewById(R.id.rightValue);
        right.setMax(180);
        
        forw = (SeekBar) dialogView.findViewById(R.id.forward);
        forw.setOnSeekBarChangeListener(this); 
        forwardValue = (TextView) dialogView.findViewById(R.id.forwardValue);
        forw.setMax(180);
         
        back = (SeekBar) dialogView.findViewById(R.id.backward);
        back.setOnSeekBarChangeListener(this); 
        backwardValue = (TextView) dialogView.findViewById(R.id.backwardValue);
        back.setMax(180);
        
        buttonLeft = (Button) dialogView.findViewById(R.id.buttonLeft);
        buttonLeft.setOnTouchListener(this);
        
        buttonRight = (Button) dialogView.findViewById(R.id.buttonRight);
        buttonRight.setOnTouchListener(this);
        
        buttonForward = (Button) dialogView.findViewById(R.id.buttonForward);
        buttonForward.setOnTouchListener(this);
        
        buttonBackward = (Button) dialogView.findViewById(R.id.buttonBackward);
        buttonBackward.setOnTouchListener(this);
    	   	
        dialogBuilder.setMessage("Robot commands");
        

        
        dialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {		
				new Control().execute("command");
			}
        }); 
        
        dialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
        	@Override
        	public void onClick(DialogInterface dialog, int id) {
                 dialog.cancel();
            }
        });
        
        AlertDialog connectip = dialogBuilder.create();
        connectip.show();
    }
    
    
     
    
    private void SensorDialog1(){
		
    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	
    	builder.setTitle("Choose sensor in port 1").setSingleChoiceItems(sensors, -1, new DialogInterface.OnClickListener(){
    		public void onClick(DialogInterface dialog, int which) {
    			switch(which){
    				case 0:
    					selection= sensors[which];
    					break;
    				case 1:
    					selection= sensors[which];
    					break;
    				case 2:
    					selection= sensors[which];
    					break;
    				case 3:
    					selection= sensors[which];
    					break;
    			}
    	
    	}
    	}).setPositiveButton("OK", new DialogInterface.OnClickListener() {
    		@Override
			public void onClick(DialogInterface dialog, int which) {
    			
    			Toast.makeText(MainActivity.this, selection,Toast.LENGTH_LONG).show();
    			
    			if(selection == "None"){
    				
    				if(connected[0] == "color") {
						colorSP.close();
					}
					if(connected[0] == "gyro") {
						gyroSP.close();
					}
					if(connected[0] == "ultra") {
						ultraSP.close();
					}
    			
    			}
    			
    			if(selection == "Ultrasonic sensor"){
    				
    				try{
    				
    					new Control().execute("connect_sensor","1","ultra");
    				}
    				
    				catch(Exception e){}
    			}
    			
    			if(selection == "Color sensor"){
    				
    				try{
    				
    					new Control().execute("connect_sensor","1","color");
    				}
    				
    				catch(Exception e){}	
    			}
    			
    			if(selection == "Gyro sensor"){
    				
    				try{
    				
    					new Control().execute("connect_sensor","1","gyro");
    				}
    				
    				catch(Exception e){}	
    			}
    			
    		}
    	});
    
    	AlertDialog connectip = builder.create();
        connectip.show();
    }
    
    
	private void SensorDialog2(){
			
	    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
	    	
	    	builder.setTitle("Choose sensor in port 2").setSingleChoiceItems(sensors, -1, new DialogInterface.OnClickListener(){
	    		public void onClick(DialogInterface dialog, int which) {
	    			switch(which){
	    				case 0:
	    					selection= sensors[which];
	    					break;
	    				case 1:
	    					selection= sensors[which];
	    					break;
	    				case 2:
	    					selection= sensors[which];
	    					break;
	    				case 3:
	    					selection= sensors[which];
	    					break;
	    			}
	    	
	    	}
	    	}).setPositiveButton("OK", new DialogInterface.OnClickListener() {
	    		@Override
				public void onClick(DialogInterface dialog, int which) {
	    			
	    			Toast.makeText(MainActivity.this, selection,Toast.LENGTH_LONG).show();
	    			
	    			if(selection == "None"){
	    				
	    				new Control().execute("monitor");
	    			
	    			}
	    			
	    			if(selection == "Ultrasonic sensor"){
	    				
	    				try{
	    					new Control().execute("connect_sensor","2","ultra");
	    				}
	    				
	    				catch(Exception e){}
	    			}
	    			
	    			if(selection == "Color sensor"){
	    				
	    				try{
	    				
	    					new Control().execute("connect_sensor","2","color");
	    				}
	    				
	    				catch(Exception e){}
	    			}
	    			
	    			if(selection == "Gyro sensor"){
	    				
	    				try{		
	    					new Control().execute("connect_sensor","2","gyro");
	    				}
	    				
	    				catch(Exception e){}
	    			}
	    		}
	    	});
	    
	    	AlertDialog connectip = builder.create();
	        connectip.show();
	    }
	
	
		
	private void SensorDialog3(){
		
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		
		builder.setTitle("Choose sensor in port 3").setSingleChoiceItems(sensors, -1, new DialogInterface.OnClickListener(){
			public void onClick(DialogInterface dialog, int which) {
				switch(which){
					case 0:
						selection= sensors[which];
						break;
					case 1:
						selection= sensors[which];
						break;
					case 2:
						selection= sensors[which];
						break;
					case 3:
						selection= sensors[which];
						break;
				}
		
		}
		}).setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				
				Toast.makeText(MainActivity.this, selection,Toast.LENGTH_LONG).show();
				
				if(selection == "None"){
					if(connected[2] == "color") {
						colorSP.close();
					}
					if(connected[2] == "gyro") {
						gyroSP.close();
					}
					if(connected[2] == "ultra") {
						ultraSP.close();
					}
						
				}
				
				if(selection == "Ultrasonic sensor"){
    				
					try{
						new Control().execute("connect_sensor","3","ultra");
					}
					
					catch(Exception e){}
    			}
    			
    			if(selection == "Color sensor"){
    				
    				try{
    					new Control().execute("connect_sensor","3","color");
    				}
  
    				catch(Exception e){}
    			}
    			
    			if(selection == "Gyro sensor"){
    				
    				try{	
    					new Control().execute("connect_sensor","3","gyro");
    				}
    				
    				catch(Exception e){}
    				
    			}
			}
		});
	
		AlertDialog connectip = builder.create();
	    connectip.show();
	}
    
    
	
	private void SensorDialog4(){
		
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		
		builder.setTitle("Choose sensor in port 4").setSingleChoiceItems(sensors, -1, new DialogInterface.OnClickListener(){
			public void onClick(DialogInterface dialog, int which) {
				switch(which){
					case 0:
						selection= sensors[which];
						break;
					case 1:
						selection= sensors[which];
						break;
					case 2:
						selection= sensors[which];
						break;
					case 3:
						selection= sensors[which];
						break;
				}
		
		}
		}).setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				
				Toast.makeText(MainActivity.this, selection,Toast.LENGTH_LONG).show();
				
				if(selection == "None"){
					
					if(connected[3] == "color") {
						colorSP.close();
					}
					if(connected[3] == "gyro") {
						gyroSP.close();
					}
					if(connected[3] == "ultra") {
						ultraSP.close();
					}
				}
				
				if(selection == "Ultrasonic sensor"){
    				
					try{
						new Control().execute("connect_sensor","4","ultra");
					}
					
    				catch(Exception e){}
    			}
    			
    			if(selection == "Color sensor"){
    				
    				try{
    					new Control().execute("connect_sensor","4","color");
    				}
    				
    				catch(Exception e){}
    			}
    			
    			if(selection == "Gyro sensor"){
    				
    				try{
    					new Control().execute("connect_sensor","4","gyro");
    				}
    				
    				catch(Exception e){}
    			}
				
				
			}
		});
	
		AlertDialog connectip = builder.create();
	    connectip.show();
	}
	
    
    
    @Override
    public void onAngleChanged(int angle) {

    	new Control().execute("rotate", "" + angle);
    }
 
    @SuppressLint("ClickableViewAccessibility")
	@Override
    public boolean onTouch(View v, MotionEvent event) {
        int action = event.getAction();
        
        if (action == MotionEvent.ACTION_UP){
        	if(switch_bool==false){
        	new Control().execute("stop");
            }
        }	
        else if (action == MotionEvent.ACTION_DOWN) {
            if (v == forward)
                new Control().execute("forward");
            else if (v == backward)
                new Control().execute("backward");
            else if (v.getId() == R.id.connect) {
            	if (ev3 == null) {
            		connectDialog();
                }
                else {
                    new Control().execute("disconnect");
                }	      
            }
            
            else if (v.getId() == R.id.Commands) {
            	if (ev3 == null) {
            		Toast.makeText(MainActivity.this, "Not connected",Toast.LENGTH_LONG).show();
            	}
                else {
                	commandsDialog();
                }
            }
            
            else if (v.getId() == R.id.buttonLeft) {
            	commands.add(leftValue.getText().toString());
            }
            
            else if (v.getId() == R.id.buttonRight) {
            	commands.add(rightValue.getText().toString());
            }
            
            else if (v.getId() == R.id.buttonForward) {
            	commands.add(forwardValue.getText().toString());
            }
            
            else if (v.getId() == R.id.buttonBackward) {            	
            	commands.add(backwardValue.getText().toString());
            }
            	
            else if (v.getId() == R.id.buttonA) {
            	SensorDialog1();
            }
            
            else if (v.getId() == R.id.buttonB) {
            	SensorDialog2();
            }
            
            else if (v.getId() == R.id.buttonC) {
            	SensorDialog3();
            }
            
            else if (v.getId() == R.id.buttonD) {
            	SensorDialog4();
            }
            
            else if (v.getId() == R.id.switch_off){
            	if(switch_bool==false){
            		switch_obr.setImageResource(R.drawable.switch_on);
            		new Control().execute("accelerometer");
            		
            		shake.setVisibility(View.VISIBLE);
            		rotateView.setVisibility(View.INVISIBLE);
            		forward.setVisibility(View.INVISIBLE);
            		backward.setVisibility(View.INVISIBLE);
            		
            	}
            	else{
	                switch_obr.setImageResource(R.drawable.switch_off);
	            	
            	    shake.setVisibility(View.INVISIBLE);
	        		rotateView.setVisibility(View.VISIBLE);
	        		forward.setVisibility(View.VISIBLE);
	        		backward.setVisibility(View.VISIBLE);
      
            	    
                }
            	switch_bool=!switch_bool;
            } 	
        }
        return false;
    }
     
    @Override
    public void onProgressChanged(SeekBar seekBar, int progress,boolean fromUser) {
        if (seekBar == speed) speedValue.setText("Travel speed: " + progress);
        else if (seekBar == rotationSpeed) rotationSpeedValue.setText("Rotation speed: " + progress);
        else if (seekBar == left) leftValue.setText("Left(degrees):" + progress);
        else if (seekBar == right) rightValue.setText("Right(degrees):" + progress);
        else if (seekBar == forw) forwardValue.setText("Forward(cm):" + progress);
        else if (seekBar == back) backwardValue.setText("Backward(cm):" + progress);
    }
 
    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
    }
 
    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {  
    }
    
    
    @Override
    protected void onResume() {
    	super.onResume();
    	Manager.registerListener(this, Manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),SensorManager.SENSOR_DELAY_UI );
        
    }
 
    @Override
    protected void onStop() {
        Manager.unregisterListener(this);
        super.onStop();
    }
 
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Do nothing
    }
 
    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
    	
    	
    	if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
    		 
    		 x = sensorEvent.values[0];
             z = sensorEvent.values[2];   
            
        }

    	
    }
     
    public static int clamp(int val, int min, int max) {
        return Math.max(min, Math.min(max, val));
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        // TODO Auto-generated method stub
        super.onConfigurationChanged(newConfig);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }
    
    

       
    
    private class Control extends AsyncTask<String, Integer, Long> {
        protected Long doInBackground(String... cmd) {
            if (cmd[0].equals("connect")) {
                try {
                    ev3 = new RemoteRequestEV3(cmd[1]);       
                    pilot = (RemoteRequestPilot) ev3.createPilot(Float.parseFloat(WheelDiam), Float.parseFloat(Diam),"B", "C");
                    
                    audio = ev3.getAudio();
                    audio.systemSound(3);
                    
                    speed.setMax((int) pilot.getMaxTravelSpeed());
                    rotationSpeed.setMax((int) pilot.getRotateMaxSpeed());
                    
                    SPEED_FACTOR = ((int)pilot.getMaxTravelSpeed()/10);
                    
                   
                    
                } catch (IOException e) {
                    return 1l;
                }
            } 
            else if (cmd[0].equals("disconnect") && ev3 != null) {
                audio.systemSound(2);
                
                if (ultraSP != null) {
                	ultraSP.close();
                	}

                if (colorSP != null) {
                	colorSP.close();
                	}
                	
                if (gyroSP != null) {
                	gyroSP.close();
                    	}
                
                pilot.close();
                ev3.disConnect();
                ev3 = null;
                return 0l;
            } 
            
            if (ev3 == null) return 2l;
            
            
            if (cmd[0].equals("monitor")){
            	monitorSensors();
            }
            
            
            if (cmd[0].equals("connect_sensor")){
               	
            	connectSensors(cmd[1],cmd[2]);
            }
            
           
            
            
            if(switch_bool==false){
	            
            	if (cmd[0].equals("command")){
            		
            		for( String oneItem : commands ) {
    					
    					if(oneItem.contains("Left")){
    						pilot.rotate(Integer.parseInt(oneItem.substring(oneItem.lastIndexOf(":") + 1)));
    					}
    					else if(oneItem.contains("Right")){
    						pilot.rotate(-(Integer.parseInt(oneItem.substring(oneItem.lastIndexOf(":") + 1))));
    					}
    					else if(oneItem.contains("Forward")){
    						pilot.travel(Integer.parseInt(oneItem.substring(oneItem.lastIndexOf(":") + 1))*10);
    					}
    					else if(oneItem.contains("Backward")){
    						pilot.travel(-(Integer.parseInt(oneItem.substring(oneItem.lastIndexOf(":") + 1))*10));
    					}
    				}
            		
            		
            	}
            	
            	if (cmd[0].equals("rotate")) {
	                
            		int newAngle = Integer.parseInt(cmd[1]);
	                
	                pilot.setRotateSpeed(rotationSpeed.getProgress());
	                try{
	                	pilot.rotate(angle - newAngle);
	                }
	                catch(Exception e){
	                }
	                angle = newAngle;
	            
            	} 
            	
	             else if (cmd[0].equals("forward")) {
	                
	                pilot.setTravelSpeed(speed.getProgress());
	                pilot.forward();
	            } else if (cmd[0].equals("backward")) {
	                
	                pilot.setTravelSpeed(speed.getProgress());
	                pilot.backward();
            	
	            }
            	
            	else if (cmd[0].equals("stop")) {
  	               
 	                pilot.stop();
 	            }
	            
            	
	           
            }
            
            if (cmd[0].equals("accelerometer")){
            	
            	pilot.stop();
            	while(switch_bool==true) {
               	 pilot.setTravelSpeed(Math.abs((int)(z * SPEED_FACTOR)));
               	 if (Math.abs(z)>3) {
                   	 if (z < 0) {
                   	     pilot.backward();
                   	     }
                   	 else pilot.forward();
                    } else if (Math.abs(x)>2) {
                   	 pilot.rotate((int)(x * TURN_FACTOR));
                    } else
                        pilot.stop();
                    Delay.msDelay(900);
                }	
            	
            }
            
                    
            return 0l;
        }
 
        protected void onPostExecute(Long result) {
            if (result == 1l)
                Toast.makeText(MainActivity.this, "Could not connect to EV3",
                        Toast.LENGTH_LONG).show();
            else if (result == 2l)
                Toast.makeText(MainActivity.this, "Not connected",
                        Toast.LENGTH_LONG).show();
        }
    }
    
    public void connectSensors(String slot, String typ) {
    	
    	if(slot == "1") {
    		switch(typ){
			case "ultra":
				try{
					ultraSP = (RemoteRequestSampleProvider) ev3.createSampleProvider("S1", "lejos.hardware.sensor.EV3UltrasonicSensor", "Distance");
			        ultraSample = new float[ultraSP.sampleSize()];
			        connected[0]= "ultra";
				}
			    catch(Exception e){}	   		
				break;
			case "gyro":
				try{
					 gyroSP = (RemoteRequestSampleProvider) ev3.createSampleProvider("S1", "lejos.hardware.sensor.EV3GyroSensor", "Angle");
				     gyroSample = new float[gyroSP.sampleSize()];
				     connected[0]= "gyro";
				}
			    catch(Exception e){}	   		
				break;
			case "color":
				try{
					 colorSP = (RemoteRequestSampleProvider) ev3.createSampleProvider("S1", "lejos.hardware.sensor.EV3ColorSensor", "ColorID");
			         colorSample = new float[colorSP.sampleSize()];
			         connected[0]= "color";
				}
			    catch(Exception e){}	   		
				break;	
    		}
    	}
    	
    	
    	if(slot == "2") {
    		switch(typ){
			case "ultra":
				try{
					ultraSP = (RemoteRequestSampleProvider) ev3.createSampleProvider("S2", "lejos.hardware.sensor.EV3UltrasonicSensor", "Distance");
			        ultraSample = new float[ultraSP.sampleSize()];
			        connected[1]= "ultra";
				}
			    catch(Exception e){}	   		
				break;
			case "gyro":
				try{
					 gyroSP = (RemoteRequestSampleProvider) ev3.createSampleProvider("S2", "lejos.hardware.sensor.EV3GyroSensor", "Angle");
				     gyroSample = new float[gyroSP.sampleSize()];
				     connected[1]= "gyro";
				     
				}
			    catch(Exception e){}	   		
				break;
			case "color":
				try{
					 colorSP = (RemoteRequestSampleProvider) ev3.createSampleProvider("S2", "lejos.hardware.sensor.EV3ColorSensor", "ColorID");
			         colorSample = new float[colorSP.sampleSize()];
			         connected[1]= "color";
				}
			    catch(Exception e){}	   		
				break;	
    		}
    	}
    	
    	
    	if(slot == "3") {
    		switch(typ){
			case "ultra":
				try{
					ultraSP = (RemoteRequestSampleProvider) ev3.createSampleProvider("S3", "lejos.hardware.sensor.EV3UltrasonicSensor", "Distance");
			        ultraSample = new float[ultraSP.sampleSize()];
			        connected[2]= "ultra";
				}
			    catch(Exception e){}	   		
				break;
			case "gyro":
				try{
					 gyroSP = (RemoteRequestSampleProvider) ev3.createSampleProvider("S3", "lejos.hardware.sensor.EV3GyroSensor", "Angle");
				     gyroSample = new float[gyroSP.sampleSize()];
				     connected[2]= "gyro";
				}
			    catch(Exception e){}	   		
				break;
			case "color":
				try{
					 colorSP = (RemoteRequestSampleProvider) ev3.createSampleProvider("S3", "lejos.hardware.sensor.EV3ColorSensor", "ColorID");
			         colorSample = new float[colorSP.sampleSize()];
			         connected[2]= "color";
			         colorSP.fetchSample(colorSample, 0);
				}
			    catch(Exception e){}	   		
				break;	
    		}
    	}
    	
    	if(slot == "4") {
    		switch(typ){
			case "ultra":
				try{
					ultraSP = (RemoteRequestSampleProvider) ev3.createSampleProvider("S4", "lejos.hardware.sensor.EV3UltrasonicSensor", "Distance");
			        ultraSample = new float[ultraSP.sampleSize()];
			        connected[3]= "ultra";
			        ultraSP.fetchSample(ultraSample, 0);
				}
			    catch(Exception e){}	   		
				break;
			case "gyro":
				try{
					 gyroSP = (RemoteRequestSampleProvider) ev3.createSampleProvider("S4", "lejos.hardware.sensor.EV3GyroSensor", "Angle");
				     gyroSample = new float[gyroSP.sampleSize()];
				     connected[3]= "gyro";
				}
			    catch(Exception e){}	   		
				break;
			case "color":
				try{
					 colorSP = (RemoteRequestSampleProvider) ev3.createSampleProvider("S4", "lejos.hardware.sensor.EV3ColorSensor", "ColorID");
			         colorSample = new float[colorSP.sampleSize()];
			         connected[3]= "color";
				}
			    catch(Exception e){}	   		
				break;	
    		}
    	}
    	
    	
    
    }
    
    
       
    
    public void monitorSensors() {
  	
       
    	
    	ultraSP = (RemoteRequestSampleProvider) ev3.createSampleProvider("S4", "lejos.hardware.sensor.EV3UltrasonicSensor", "Distance");
        ultraSample = new float[ultraSP.sampleSize()];
        
        colorSP = (RemoteRequestSampleProvider) ev3.createSampleProvider("S3", "lejos.hardware.sensor.EV3ColorSensor", "ColorID");
        colorSample = new float[colorSP.sampleSize()];
        
        gyroSP = (RemoteRequestSampleProvider) ev3.createSampleProvider("S1", "lejos.hardware.sensor.EV3GyroSensor", "Angle");
        gyroSample = new float[gyroSP.sampleSize()];

        threads.submit(new Runnable() {
            @Override
        	public void run() {

                while (!threads.isShutdown()) {
                    try {
                        
                    	TimeUnit.MILLISECONDS.sleep(200);

                        ultraSP.fetchSample(ultraSample, 0);
                        colorSP.fetchSample(colorSample, 0);
                        gyroSP.fetchSample(gyroSample, 0);
                        
                        int colorId = (int)colorSample[0];
                        colorName = "";
                		switch(colorId){
                			case Color.NONE: colorName = "NONE"; break;
                			case Color.BLACK: colorName = "BLACK"; break;
                			case Color.WHITE: colorName = "WHITE"; break;
                			case Color.BLUE: colorName = "BLUE"; break;
                			case Color.GREEN: colorName = "GREEN"; break;
                			case Color.YELLOW: colorName = "YELLOW"; break;
                			case Color.RED: colorName = "RED"; break;
                			case Color.BROWN: colorName = "BROWN"; break;
                		}
                                 
                		MainActivity.this.runOnUiThread(new Runnable() {
                            public void run() {
                   
                            	String formattedString = String.format("%.02f", ultraSample[0]);
                            	
                            	sensorA.setText("" + gyroSample[0]+ " �C");
                                sensorC.setText(colorName);
                                sensorD.setText(formattedString + " m");
                                
                            }
                        });
               
                    } catch (InterruptedException e) {

                        Toast.makeText(MainActivity.this,e.getLocalizedMessage(),Toast.LENGTH_LONG).show();e.printStackTrace();
                    }
                }
            }
        });
    }
        
    
}
